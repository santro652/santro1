# Journey Builder Activity 
### Starter template for a messaging JB Activity using Node.JS

**NOTE:** This app and the associated code is NOT production quality, its pure purpose is to demonstrate the full flow of custom interactions in Journey Builder

Also, follow me on [LinkedIn](https://www.linkedin.com/in/bhanu-prakash-avula-8292777b/) to get the latest updates and great articles about Salesforce Marketing Cloud!
